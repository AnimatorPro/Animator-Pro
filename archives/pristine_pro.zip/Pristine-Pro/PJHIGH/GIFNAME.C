
char gif_pdr_name[] = "GIF.PDR";

