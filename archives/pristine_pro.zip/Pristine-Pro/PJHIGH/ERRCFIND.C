#include "pjbasics.h"

void cant_find(char *name)
{
	soft_continu_box("!%s","cant_find",name);
}
