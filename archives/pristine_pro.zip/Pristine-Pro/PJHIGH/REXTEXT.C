char *load_rex_keyed_text(char *symbol, char *key_or_text,char **ptext)
/* puts allocated  
{



}
	if( ((soft_text = rex_key_or_text(info_text,&info_text)) != NULL)
		&& (smu_load_name_text(&smu_sm,"vdriver_texts", 
							   soft_text, &soft_text) >= Success))
	{
		info_text = soft_text;
	}
