#ifndef RELEASE_H
#define RELEASE_H

#define TESTING

#endif /* RELEASE_H */
