int intabs(int a)
{
return(a >= 0 ? a : -a);
}
