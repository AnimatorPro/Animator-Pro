int intmin(int a, int b)
{
return( a < b ? a : b);
}
